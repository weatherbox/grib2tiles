
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.1'
version = '1.11.1'
full_version = '1.11.1'
git_revision = 'ccc6b8d8fcf92cc6dc19f7e14d91fc6c127114a6'
release = True

if not release:
    version = full_version
